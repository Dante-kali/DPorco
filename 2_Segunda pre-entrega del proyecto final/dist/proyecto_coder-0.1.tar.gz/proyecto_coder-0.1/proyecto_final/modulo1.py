def sumar(num:int):
    for xx in range(num):
        num + 1 
    