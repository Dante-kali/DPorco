import time

def cortar(mi_texto:str):

    for i in enumerate(mi_texto):
        time.sleep(0.3)

        print(i)
    
cortar("Ces't la mort")