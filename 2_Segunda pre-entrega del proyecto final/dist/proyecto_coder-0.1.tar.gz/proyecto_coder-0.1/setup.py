from setuptools import setup, find_packages

setup(
    name='proyecto_coder',
    version='0.1',
    packages=find_packages(),
    description='paquete pre_entrega',
    author='Tu Nombre',
    author_email='porcodante8@example.com',
    license='MIT',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
    ],
    keywords='ejemplo paquete',
)